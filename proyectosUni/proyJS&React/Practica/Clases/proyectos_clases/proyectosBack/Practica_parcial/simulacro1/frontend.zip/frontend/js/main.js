// JavaScript principal del frontend
const API_URL = "http://localhost:3000/api/peliculas";

async function cargarPeliculas() {
  const anio = document.getElementById("filtroAnio").value;
  const url = anio ? `${API_URL}?anio=${anio}` : API_URL;
  const res = await fetch(url);
  const peliculas = await res.json();
  const tbody = document.querySelector("#tablaPeliculas tbody");
  tbody.innerHTML = "";
  peliculas.forEach(p => {
    const fila = `<tr><td>${p.Titulo}</td><td>${p.Director}</td><td>${p.Anio}</td><td>${p.Genero || ""}</td></tr>`;
    tbody.innerHTML += fila;
  });
}

document.getElementById("formulario").addEventListener("submit", async e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  console.log("Datos del formulario:", data);
  if (!data.titulo || !data.director || !data.anio) {
    alert("Por favor completá todos los campos obligatorios.");
    return;
  }
  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      Titulo: data.titulo,
      Director: data.director,
      Anio: parseInt(data.anio),
      Genero: data.genero
    })
  });
  e.target.reset();
  cargarPeliculas();
});

cargarPeliculas();

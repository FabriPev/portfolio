import express from 'express';
import categoriasmock from './routes/categoriasmock.js';

//Crear serividor express
const app = express();
app.use(express.json()); //Para poder recibir datos en formato JSON

//Controlador de la ruta raíz
app.get('/', (req, res) => {
    res.send('Backend inicial dds-backend');
})

//levantamiento del servidor
const port = 3000;
app.locals.fechaInicio = new Date(); //Fecha de inicio del servidor
app.listen(port, () => {
    console.log(`Sitio escuchando el puerto ${port}`);
})

//Rutas
app.use('/', categoriasmock);
